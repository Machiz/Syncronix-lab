/*
  Ejemplo mínimo para ESP32 + módulo LDR de 3 pines.
  El ordenador NO puede descubrir por sí solo a qué GPIO llega un cable.
  Este agente declara el pin utilizado y envía evidencia eléctrica en JSON.
*/

// @sensor LDR; signal=AO; pin=34; mode=INPUT; interface=ANALOG; voltage=3.3
const int LDR_AO_PIN = 34;  // Sensor: módulo LDR, salida analógica AO

const unsigned long REPORT_MS = 500;
unsigned long lastReport = 0;

void sendHello() {
  Serial.println(
    "{\"type\":\"hello\",\"board\":\"ESP32\",\"firmware\":\"wirewatch-ldr-1.0\"}"
  );
}

void sendLdrDiagnostic() {
  const int raw = analogRead(LDR_AO_PIN);
  const float voltage = (raw / 4095.0f) * 3.3f;

  Serial.print("{\"type\":\"pin\",\"sensor\":\"LDR\",\"signal\":\"AO\",");
  Serial.print("\"physical_pin\":\"34\",\"mode\":\"INPUT\",");
  Serial.print("\"interface\":\"ANALOG\",\"detected\":true,");
  Serial.print("\"ground_common\":true,\"power_ok\":true,");
  Serial.print("\"value\":");
  Serial.print(raw);
  Serial.print(",\"voltage\":");
  Serial.print(voltage, 3);
  Serial.println("}");
}

void setup() {
  Serial.begin(115200);
  delay(500);
  pinMode(LDR_AO_PIN, INPUT);
  sendHello();
}

void loop() {
  if (Serial.available()) {
    String command = Serial.readStringUntil('\n');
    if (command.indexOf("\"cmd\":\"diagnose\"") >= 0) {
      sendLdrDiagnostic();
    }
  }

  if (millis() - lastReport >= REPORT_MS) {
    lastReport = millis();
    sendLdrDiagnostic();
  }
}
