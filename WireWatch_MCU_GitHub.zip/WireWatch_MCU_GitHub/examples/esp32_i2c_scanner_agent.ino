#include <Wire.h>

// @sensor I2C-BUS; signal=SDA; pin=21; mode=INPUT_PULLUP; interface=I2C
const int I2C_SDA_PIN = 21;  // Bus de sensores I2C: SDA
// @sensor I2C-BUS; signal=SCL; pin=22; mode=INPUT_PULLUP; interface=I2C
const int I2C_SCL_PIN = 22;  // Bus de sensores I2C: SCL

void setup() {
  Serial.begin(115200);
  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);
  Serial.println("{\"type\":\"hello\",\"board\":\"ESP32\",\"firmware\":\"wirewatch-i2c-1.0\"}");
}

void scanI2C() {
  int found = 0;
  for (uint8_t address = 1; address < 127; ++address) {
    Wire.beginTransmission(address);
    uint8_t error = Wire.endTransmission();
    if (error == 0) {
      Serial.print("{\"type\":\"bus\",\"sensor\":\"I2C-BUS\",\"signal\":\"DEVICE\",");
      Serial.print("\"physical_pin\":\"21/22\",\"interface\":\"I2C\",");
      Serial.print("\"detected\":true,\"address\":\"0x");
      if (address < 16) Serial.print("0");
      Serial.print(address, HEX);
      Serial.println("\"}");
      found++;
    }
  }
  if (found == 0) {
    Serial.println(
      "{\"type\":\"bus\",\"sensor\":\"I2C-BUS\",\"signal\":\"DEVICE\","
      "\"physical_pin\":\"21/22\",\"interface\":\"I2C\",\"detected\":false,"
      "\"communication_error\":\"No se encontraron respuestas ACK en el bus I2C\"}"
    );
  }
}

void loop() {
  if (Serial.available()) {
    String command = Serial.readStringUntil('\n');
    if (command.indexOf("\"cmd\":\"diagnose\"") >= 0) {
      scanI2C();
    }
  }
  delay(20);
}
