# MicroPython: ejemplo de protocolo WireWatch.
import sys
import time
import ujson
from machine import ADC, Pin

# @sensor LDR; signal=AO; pin=34; mode=INPUT; interface=ANALOG; voltage=3.3
ldr = ADC(Pin(34))  # Sensor: módulo LDR, salida AO
try:
    ldr.atten(ADC.ATTN_11DB)
except AttributeError:
    pass

print(ujson.dumps({
    "type": "hello",
    "board": sys.platform,
    "firmware": "wirewatch-micropython-1.0",
}))

while True:
    raw = ldr.read()
    print(ujson.dumps({
        "type": "pin",
        "sensor": "LDR",
        "signal": "AO",
        "physical_pin": "34",
        "mode": "INPUT",
        "interface": "ANALOG",
        "detected": True,
        "ground_common": True,
        "power_ok": True,
        "value": raw,
    }))
    time.sleep_ms(500)
