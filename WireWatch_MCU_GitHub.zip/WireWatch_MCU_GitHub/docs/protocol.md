# Protocolo WireWatch MCU v1

Cada mensaje es un objeto JSON UTF-8 terminado en salto de línea.

## PC → microcontrolador

```json
{"cmd":"diagnose","version":1}
```

## Microcontrolador → PC

Identificación:

```json
{"type":"hello","board":"ESP32","firmware":"wirewatch-1.0"}
```

Pin o señal:

```json
{
  "type":"pin",
  "sensor":"LDR",
  "signal":"AO",
  "physical_pin":"34",
  "mode":"INPUT",
  "interface":"ANALOG",
  "detected":true,
  "value":2050,
  "voltage":1.65,
  "ground_common":true,
  "power_ok":true
}
```

Dispositivo de bus:

```json
{
  "type":"bus",
  "sensor":"BME280",
  "signal":"DEVICE",
  "physical_pin":"21/22",
  "interface":"I2C",
  "address":"0x76",
  "detected":true
}
```

Error de comunicación:

```json
{
  "type":"bus",
  "sensor":"BME280",
  "signal":"DEVICE",
  "interface":"I2C",
  "detected":false,
  "communication_error":"No responde en 0x76"
}
```

Campos opcionales de evidencia:

- `continuity_ok`: requiere hardware de prueba.
- `ground_common`: requiere medición o prueba explícita.
- `power_ok`: indica que la fuente fue medida dentro de rango.
- `voltage`: tensión medida.
- `value`: lectura bruta o procesada.
