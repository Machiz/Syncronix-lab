from __future__ import annotations

import re
from pathlib import Path
from .models import ExpectedConnection


DEFINE_PATTERNS = [
    re.compile(r"^\s*#define\s+(?P<name>[A-Za-z_]\w*)\s+(?P<pin>[A-Za-z0-9_]+)"),
    re.compile(
        r"^\s*(?:const\s+)?(?:int|uint8_t|byte|gpio_num_t)\s+"
        r"(?P<name>[A-Za-z_]\w*)\s*=\s*(?P<pin>[A-Za-z0-9_]+)\s*;"
    ),
]

PY_PIN_PATTERN = re.compile(
    r"^\s*(?P<name>[A-Za-z_]\w*)\s*=\s*(?:machine\.)?Pin\(\s*(?P<pin>\d+)"
)

ANNOTATION_PATTERN = re.compile(
    r"@sensor\s+(?P<sensor>[^;]+?)\s*;\s*"
    r"signal=(?P<signal>[^;]+?)\s*;\s*"
    r"pin=(?P<pin>[^;]+?)"
    r"(?:\s*;\s*mode=(?P<mode>[^;]+?))?"
    r"(?:\s*;\s*interface=(?P<interface>[^;]+?))?"
    r"(?:\s*;\s*address=(?P<address>[^;]+?))?"
    r"(?:\s*;\s*voltage=(?P<voltage>[^;]+?))?\s*$",
    re.IGNORECASE,
)

SENSOR_COMMENT_PATTERN = re.compile(
    r"(?:sensor|m[oó]dulo|module)\s*[:=-]\s*(?P<sensor>[A-Za-z0-9_\- ./]+)",
    re.IGNORECASE,
)


def _parse_voltage(text: str | None) -> tuple[float | None, float | None]:
    if not text:
        return None, None
    numbers = re.findall(r"\d+(?:\.\d+)?", text.replace(",", "."))
    if not numbers:
        return None, None
    vals = [float(x) for x in numbers]
    if len(vals) == 1:
        return vals[0] * 0.90, vals[0] * 1.10
    return min(vals[0], vals[1]), max(vals[0], vals[1])


def parse_source(path: str | Path) -> list[ExpectedConnection]:
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    symbols: dict[str, tuple[str, int, str]] = {}
    explicit: list[ExpectedConnection] = []

    for number, line in enumerate(lines, start=1):
        ann = ANNOTATION_PATTERN.search(line.lstrip("/# *"))
        if ann:
            vmin, vmax = _parse_voltage(ann.group("voltage"))
            explicit.append(
                ExpectedConnection(
                    sensor=ann.group("sensor").strip(),
                    signal=ann.group("signal").strip(),
                    code_pin=ann.group("pin").strip(),
                    expected_mode=(ann.group("mode") or "").strip().upper(),
                    interface=(ann.group("interface") or "").strip().upper(),
                    expected_address=(ann.group("address") or "").strip(),
                    voltage_min=vmin,
                    voltage_max=vmax,
                    source_line=number,
                )
            )
            continue

        py_match = PY_PIN_PATTERN.search(line)
        if py_match:
            symbols[py_match.group("name")] = (
                py_match.group("pin"), number, line
            )
            continue

        for pattern in DEFINE_PATTERNS:
            match = pattern.search(line)
            if match:
                symbols[match.group("name")] = (
                    match.group("pin"), number, line
                )
                break

    if explicit:
        return explicit

    # Heuristic mode: uses sensor/module names written in comments near pin constants.
    results: list[ExpectedConnection] = []
    for name, (pin, number, line) in symbols.items():
        nearby = " ".join(lines[max(0, number - 3): min(len(lines), number + 1)])
        sensor_match = SENSOR_COMMENT_PATTERN.search(nearby)
        sensor = sensor_match.group("sensor").strip() if sensor_match else _sensor_from_symbol(name)
        signal = _signal_from_symbol(name)
        results.append(
            ExpectedConnection(
                sensor=sensor,
                signal=signal,
                code_pin=str(pin),
                source_line=number,
                notes="Detectado de forma heurística; use @sensor para mayor precisión.",
            )
        )
    return results


def _sensor_from_symbol(name: str) -> str:
    upper = name.upper()
    common = (
        "DHT22", "DHT11", "BME280", "BMP280", "MPU6050", "VL53L0X",
        "HC_SR04", "HCSR04", "DS18B20", "LDR", "PIR", "OLED", "SERVO",
        "MQ2", "MQ_2",
    )
    for token in common:
        if token in upper:
            return token.replace("_", "-")
    pieces = [p for p in re.split(r"_?PIN_?|_", upper) if p]
    return pieces[0] if pieces else name


def _signal_from_symbol(name: str) -> str:
    upper = name.upper()
    for token in ("SDA", "SCL", "TRIG", "ECHO", "DATA", "AO", "DO", "PWM", "RX", "TX", "CS", "MOSI", "MISO", "SCK"):
        if token in upper:
            return token
    return name
