from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import QObject, QTimer, Signal, Slot
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from .catalog import SensorCatalog
from .code_parser import parse_source
from .diagnosis import diagnose_all
from .models import ExpectedConnection, Telemetry
from .transports import SerialJsonTransport, discover_serial_ports


BASE_DIR = Path(__file__).resolve().parents[2]


class Bridge(QObject):
    telemetry = Signal(object)
    log = Signal(str)


class MainWindow(QMainWindow):
    HEADERS = [
        "Sensor / señal",
        "Pin definido en el código",
        "Pin conectado físicamente",
        "Coincidencia",
        "Configuración detectada",
        "Corrección necesaria",
        "Causa más probable",
        "Clasificación",
    ]

    def __init__(self):
        super().__init__()
        self.setWindowTitle("WireWatch MCU — Supervisor de conexiones")
        self.resize(1500, 850)

        data_dir = BASE_DIR / "data"
        self.catalog = SensorCatalog(
            data_dir / "sensor_catalog.sqlite3",
            BASE_DIR / "src" / "wirewatch" / "resources" / "sensors_seed.json",
        )
        self.expected: list[ExpectedConnection] = []
        self.telemetry: list[Telemetry] = []
        self.current_file: Path | None = None

        self.bridge = Bridge()
        self.bridge.telemetry.connect(self._on_telemetry)
        self.bridge.log.connect(self._append_log)
        self.transport = SerialJsonTransport(
            on_telemetry=self.bridge.telemetry.emit,
            on_log=self.bridge.log.emit,
        )

        self._build_ui()
        self._scan_ports()

        self.port_timer = QTimer(self)
        self.port_timer.timeout.connect(self._scan_ports)
        self.port_timer.start(2500)

        self.diagnosis_timer = QTimer(self)
        self.diagnosis_timer.timeout.connect(self._refresh_diagnosis)
        self.diagnosis_timer.start(500)

    def _build_ui(self):
        central = QWidget()
        layout = QVBoxLayout(central)

        toolbar = QHBoxLayout()
        self.load_btn = QPushButton("Cargar código")
        self.load_btn.clicked.connect(self._load_code)
        toolbar.addWidget(self.load_btn)

        self.file_label = QLabel("Sin archivo")
        toolbar.addWidget(self.file_label, 1)

        self.port_combo = QComboBox()
        self.port_combo.setMinimumWidth(280)
        toolbar.addWidget(self.port_combo)

        self.baud_spin = QSpinBox()
        self.baud_spin.setRange(1200, 2_000_000)
        self.baud_spin.setValue(115200)
        toolbar.addWidget(self.baud_spin)

        self.connect_btn = QPushButton("Conectar")
        self.connect_btn.clicked.connect(self._toggle_connection)
        toolbar.addWidget(self.connect_btn)

        self.request_btn = QPushButton("Solicitar diagnóstico")
        self.request_btn.clicked.connect(self._request_diagnostic)
        toolbar.addWidget(self.request_btn)

        self.online_check = QCheckBox("Enriquecer catálogo por internet")
        self.online_check.setChecked(True)
        toolbar.addWidget(self.online_check)

        self.import_btn = QPushButton("Importar ficha JSON")
        self.import_btn.clicked.connect(self._import_catalog)
        toolbar.addWidget(self.import_btn)

        layout.addLayout(toolbar)

        self.table = QTableWidget(0, len(self.HEADERS))
        self.table.setHorizontalHeaderLabels(self.HEADERS)
        self.table.setAlternatingRowColors(True)
        self.table.setWordWrap(True)
        self.table.horizontalHeader().setStretchLastSection(True)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(220)

        splitter = QSplitter()
        table_container = QWidget()
        table_layout = QVBoxLayout(table_container)
        table_layout.addWidget(self.table)
        splitter.addWidget(table_container)
        splitter.addWidget(self.log)
        splitter.setOrientation(splitter.Orientation.Vertical)
        splitter.setSizes([650, 180])

        layout.addWidget(splitter)
        self.setCentralWidget(central)
        self.statusBar().showMessage(
            "Cargue un archivo .ino/.cpp/.h/.py con comentarios @sensor."
        )

    @Slot()
    def _scan_ports(self):
        selected = self.port_combo.currentData()
        ports = discover_serial_ports()
        current_devices = [self.port_combo.itemData(i) for i in range(self.port_combo.count())]
        new_devices = [p.device for p in ports]
        if current_devices == new_devices:
            return
        self.port_combo.clear()
        for port in ports:
            label = f"{port.device} — {port.description}"
            self.port_combo.addItem(label, port.device)
        if selected in new_devices:
            self.port_combo.setCurrentIndex(new_devices.index(selected))

    @Slot()
    def _load_code(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Seleccionar código",
            str(Path.home()),
            "Código (*.ino *.cpp *.c *.h *.hpp *.py);;Todos (*.*)",
        )
        if not path:
            return
        try:
            self.current_file = Path(path)
            self.expected = parse_source(path)
            self.telemetry.clear()
            self.file_label.setText(self.current_file.name)
            self._append_log(
                f"Código cargado: {path}. Conexiones esperadas: {len(self.expected)}."
            )
            if not self.expected:
                QMessageBox.warning(
                    self,
                    "No se encontraron pines",
                    "No se detectaron definiciones. Use comentarios como:\n"
                    "// @sensor LDR; signal=AO; pin=34; mode=INPUT; "
                    "interface=ANALOG; voltage=3.3",
                )
            elif self.online_check.isChecked():
                self._enrich_detected_sensors()
            self._refresh_diagnosis()
        except Exception as exc:
            QMessageBox.critical(self, "Error al leer código", str(exc))

    def _enrich_detected_sensors(self):
        names = sorted({x.sensor for x in self.expected if x.sensor})
        for name in names:
            if self.catalog.find(name):
                continue
            try:
                found = self.catalog.enrich_from_wikipedia(name)
                if found:
                    self._append_log(
                        f"Resumen online almacenado para {name} "
                        "(datos eléctricos aún requieren ficha revisada)."
                    )
            except Exception as exc:
                self._append_log(f"No se pudo enriquecer {name}: {exc}")

    @Slot()
    def _toggle_connection(self):
        if self.transport.connected:
            self.transport.disconnect()
            self.connect_btn.setText("Conectar")
            self.statusBar().showMessage("Desconectado.")
            return
        port = self.port_combo.currentData()
        if not port:
            QMessageBox.warning(self, "Sin puerto", "No se encontró un puerto serial.")
            return
        try:
            self.transport.connect(port, self.baud_spin.value())
            self.connect_btn.setText("Desconectar")
            self.statusBar().showMessage(f"Conectado a {port}.")
        except Exception as exc:
            QMessageBox.critical(self, "No se pudo conectar", str(exc))

    @Slot()
    def _request_diagnostic(self):
        try:
            self.transport.send({"cmd": "diagnose", "version": 1})
            self._append_log("TX: solicitud de diagnóstico.")
        except Exception as exc:
            QMessageBox.warning(self, "No conectado", str(exc))

    @Slot(object)
    def _on_telemetry(self, item: Telemetry):
        if item.type == "hello":
            self._append_log(
                f"Equipo: {item.raw.get('board', 'desconocido')} / "
                f"firmware {item.raw.get('firmware', 'sin versión')}."
            )
        elif item.type in {"pin", "bus", "power", "device", "diagnostic"}:
            self.telemetry.append(item)
            # Keep recent evidence without unbounded growth.
            if len(self.telemetry) > 2000:
                self.telemetry = self.telemetry[-1000:]
        else:
            self._append_log(f"RX: {item.raw}")

    @Slot()
    def _refresh_diagnosis(self):
        results = diagnose_all(self.expected, self.telemetry, self.catalog.find)
        self.table.setRowCount(len(results))
        for row, result in enumerate(results):
            values = [
                f"{result.sensor} / {result.signal}",
                result.code_pin,
                result.physical_pin,
                result.match,
                result.detected_configuration,
                result.correction,
                result.probable_cause,
                result.classification.value,
            ]
            for col, value in enumerate(values):
                self.table.setItem(row, col, QTableWidgetItem(str(value)))
        self.table.resizeColumnsToContents()
        self.table.resizeRowsToContents()

    @Slot()
    def _import_catalog(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Importar ficha de sensor", str(Path.home()), "JSON (*.json)"
        )
        if not path:
            return
        try:
            count = self.catalog.import_json(path)
            self._append_log(f"Fichas importadas: {count}.")
            self._refresh_diagnosis()
        except Exception as exc:
            QMessageBox.critical(self, "Error de importación", str(exc))

    @Slot(str)
    def _append_log(self, text: str):
        self.log.append(text)

    def closeEvent(self, event):
        self.transport.disconnect()
        event.accept()


def run():
    app = QApplication(sys.argv)
    app.setApplicationName("WireWatch MCU")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
