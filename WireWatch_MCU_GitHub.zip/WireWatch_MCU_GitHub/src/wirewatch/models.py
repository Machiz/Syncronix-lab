from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ProblemClass(str, Enum):
    NO_PROBLEM = "Sin problema detectado."
    INCORRECT_CONNECTION = "Conexión incorrecta."
    INCORRECT_POWER = "Alimentación incorrecta."
    MISSING_COMMON_GROUND = "Tierra común ausente."
    INCORRECT_SOFTWARE = "Configuración de software incorrecta."
    COMMUNICATION_ERROR = "Error de comunicación."
    POSSIBLY_DAMAGED = "Componente posiblemente dañado."
    INSUFFICIENT_INFO = "Información insuficiente."


@dataclass(slots=True)
class ExpectedConnection:
    sensor: str
    signal: str
    code_pin: str
    expected_mode: str = ""
    interface: str = ""
    expected_address: str = ""
    voltage_min: float | None = None
    voltage_max: float | None = None
    notes: str = ""
    source_line: int = 0


@dataclass(slots=True)
class Telemetry:
    type: str
    sensor: str = ""
    signal: str = ""
    physical_pin: str = ""
    mode: str = ""
    interface: str = ""
    address: str = ""
    detected: bool | None = None
    value: Any = None
    voltage: float | None = None
    rail: str = ""
    message: str = ""
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class Diagnosis:
    sensor: str
    signal: str
    code_pin: str
    physical_pin: str
    match: str
    detected_configuration: str
    correction: str
    probable_cause: str
    classification: ProblemClass
