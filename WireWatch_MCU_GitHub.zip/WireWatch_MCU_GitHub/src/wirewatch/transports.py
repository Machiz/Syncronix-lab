from __future__ import annotations

import json
import threading
import time
from dataclasses import dataclass
from typing import Callable

import serial
from serial.tools import list_ports

from .models import Telemetry


@dataclass(slots=True)
class PortDescriptor:
    device: str
    description: str
    hwid: str
    vid: int | None = None
    pid: int | None = None


def discover_serial_ports() -> list[PortDescriptor]:
    return [
        PortDescriptor(
            device=p.device,
            description=p.description or "",
            hwid=p.hwid or "",
            vid=p.vid,
            pid=p.pid,
        )
        for p in list_ports.comports()
    ]


class SerialJsonTransport:
    def __init__(
        self,
        on_telemetry: Callable[[Telemetry], None],
        on_log: Callable[[str], None],
    ):
        self.on_telemetry = on_telemetry
        self.on_log = on_log
        self._serial: serial.Serial | None = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()

    @property
    def connected(self) -> bool:
        return bool(self._serial and self._serial.is_open)

    def connect(self, port: str, baudrate: int) -> None:
        self.disconnect()
        self._serial = serial.Serial(port=port, baudrate=baudrate, timeout=0.3)
        self._stop.clear()
        self._thread = threading.Thread(target=self._reader_loop, daemon=True)
        self._thread.start()
        self.on_log(f"Conectado a {port} a {baudrate} baudios.")

    def disconnect(self) -> None:
        self._stop.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1.0)
        if self._serial and self._serial.is_open:
            self._serial.close()
        self._serial = None

    def send(self, payload: dict) -> None:
        if not self.connected or self._serial is None:
            raise RuntimeError("No hay conexión serial.")
        self._serial.write((json.dumps(payload) + "\n").encode("utf-8"))

    def _reader_loop(self) -> None:
        assert self._serial is not None
        while not self._stop.is_set():
            try:
                raw = self._serial.readline()
                if not raw:
                    continue
                line = raw.decode("utf-8", errors="replace").strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    self.on_log(f"RX no JSON: {line}")
                    continue
                telemetry = telemetry_from_dict(data)
                self.on_telemetry(telemetry)
            except (serial.SerialException, OSError) as exc:
                self.on_log(f"Error serial: {exc}")
                break
            except Exception as exc:
                self.on_log(f"Error inesperado en transporte: {exc}")
                time.sleep(0.2)


def telemetry_from_dict(data: dict) -> Telemetry:
    return Telemetry(
        type=str(data.get("type", "unknown")),
        sensor=str(data.get("sensor", "")),
        signal=str(data.get("signal", "")),
        physical_pin=str(data.get("physical_pin", data.get("pin", ""))),
        mode=str(data.get("mode", "")),
        interface=str(data.get("interface", "")),
        address=str(data.get("address", "")),
        detected=data.get("detected"),
        value=data.get("value"),
        voltage=_to_float(data.get("voltage")),
        rail=str(data.get("rail", "")),
        message=str(data.get("message", "")),
        raw=data,
    )


def _to_float(value):
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None
