from __future__ import annotations

from collections import defaultdict
from .models import (
    Diagnosis,
    ExpectedConnection,
    ProblemClass,
    Telemetry,
)


def diagnose_all(
    expected: list[ExpectedConnection],
    telemetry: list[Telemetry],
    catalog_lookup,
) -> list[Diagnosis]:
    by_key: dict[tuple[str, str], list[Telemetry]] = defaultdict(list)
    for item in telemetry:
        by_key[(item.sensor.lower(), item.signal.lower())].append(item)

    results: list[Diagnosis] = []
    for exp in expected:
        candidates = by_key.get((exp.sensor.lower(), exp.signal.lower()), [])
        if not candidates:
            candidates = [
                t for t in telemetry
                if t.signal.lower() == exp.signal.lower()
                and (not t.sensor or t.sensor.lower() == exp.sensor.lower())
            ]
        observation = candidates[-1] if candidates else None
        catalog = catalog_lookup(exp.sensor)
        results.append(diagnose_one(exp, observation, catalog))
    return results


def diagnose_one(
    exp: ExpectedConnection,
    obs: Telemetry | None,
    catalog: dict | None,
) -> Diagnosis:
    expected_pin = normalize_pin(exp.code_pin)

    if obs is None:
        return Diagnosis(
            sensor=exp.sensor,
            signal=exp.signal,
            code_pin=exp.code_pin,
            physical_pin="No informado",
            match="No verificable",
            detected_configuration="Sin telemetría compatible",
            correction="Cargar el agente de diagnóstico y revisar puerto, baudios y protocolo JSON.",
            probable_cause="El ordenador no recibió evidencia suficiente para relacionar el pin lógico con una conexión física.",
            classification=ProblemClass.INSUFFICIENT_INFO,
        )

    physical_pin = obs.physical_pin or "No informado"
    actual_pin = normalize_pin(physical_pin)
    pin_match = bool(expected_pin and actual_pin and expected_pin == actual_pin)

    config_parts = []
    if obs.mode:
        config_parts.append(f"modo={obs.mode}")
    if obs.interface:
        config_parts.append(f"interfaz={obs.interface}")
    if obs.address:
        config_parts.append(f"dirección={obs.address}")
    if obs.voltage is not None:
        config_parts.append(f"voltaje={obs.voltage:.3f} V")
    if obs.value is not None:
        config_parts.append(f"valor={obs.value}")
    detected_config = ", ".join(config_parts) or "Telemetría recibida sin configuración detallada"

    vmin, vmax = exp.voltage_min, exp.voltage_max
    if catalog:
        vmin = vmin if vmin is not None else catalog.get("voltage_min")
        vmax = vmax if vmax is not None else catalog.get("voltage_max")

    if obs.voltage is not None and vmin is not None and vmax is not None:
        if not (float(vmin) <= obs.voltage <= float(vmax)):
            return Diagnosis(
                exp.sensor, exp.signal, exp.code_pin, physical_pin, "No",
                detected_config,
                f"Usar una alimentación dentro de {vmin:g}–{vmax:g} V y comprobar regulación.",
                "El voltaje medido está fuera del intervalo admitido por la ficha local.",
                ProblemClass.INCORRECT_POWER,
            )

    if obs.raw.get("ground_common") is False:
        return Diagnosis(
            exp.sensor, exp.signal, exp.code_pin, physical_pin, "No",
            detected_config,
            "Unir GND del microcontrolador, sensor y fuente externa.",
            "Las señales no tienen una referencia eléctrica común.",
            ProblemClass.MISSING_COMMON_GROUND,
        )

    if obs.raw.get("communication_error"):
        return Diagnosis(
            exp.sensor, exp.signal, exp.code_pin, physical_pin, "No verificable",
            detected_config,
            "Revisar cable, controlador, puerto, baudios, dirección y resistencias del bus.",
            str(obs.raw.get("communication_error")),
            ProblemClass.COMMUNICATION_ERROR,
        )

    if obs.detected is False:
        damaged_hint = obs.raw.get("continuity_ok") is True and obs.raw.get("power_ok") is True
        if damaged_hint:
            return Diagnosis(
                exp.sensor, exp.signal, exp.code_pin, physical_pin, "No",
                detected_config,
                "Probar el componente con otro microcontrolador o reemplazarlo temporalmente.",
                "Hay continuidad y alimentación, pero el dispositivo no responde.",
                ProblemClass.POSSIBLY_DAMAGED,
            )
        return Diagnosis(
            exp.sensor, exp.signal, exp.code_pin, physical_pin, "No",
            detected_config,
            "Confirmar el cableado, la dirección del bus y el pin indicado en el código.",
            "El dispositivo esperado no fue detectado en la interfaz informada.",
            ProblemClass.INCORRECT_CONNECTION,
        )

    if exp.expected_mode and obs.mode and exp.expected_mode.upper() != obs.mode.upper():
        return Diagnosis(
            exp.sensor, exp.signal, exp.code_pin, physical_pin,
            "Sí" if pin_match else "No",
            detected_config,
            f"Configurar {exp.code_pin} como {exp.expected_mode}.",
            f"El pin usa modo {obs.mode}, pero el código anotado requiere {exp.expected_mode}.",
            ProblemClass.INCORRECT_SOFTWARE,
        )

    if exp.interface and obs.interface and exp.interface.upper() != obs.interface.upper():
        return Diagnosis(
            exp.sensor, exp.signal, exp.code_pin, physical_pin,
            "Sí" if pin_match else "No",
            detected_config,
            f"Usar la interfaz {exp.interface} o corregir la anotación/código.",
            "La interfaz detectada no coincide con la interfaz esperada.",
            ProblemClass.INCORRECT_SOFTWARE,
        )

    if exp.expected_address and obs.address and normalize_address(exp.expected_address) != normalize_address(obs.address):
        return Diagnosis(
            exp.sensor, exp.signal, exp.code_pin, physical_pin,
            "Sí" if pin_match else "No",
            detected_config,
            f"Configurar la dirección {exp.expected_address} o ajustar el hardware de dirección.",
            "La dirección detectada no coincide con la declarada en el código.",
            ProblemClass.INCORRECT_SOFTWARE,
        )

    if expected_pin and actual_pin and not pin_match:
        return Diagnosis(
            exp.sensor, exp.signal, exp.code_pin, physical_pin, "No",
            detected_config,
            f"Mover la señal {exp.signal} a {exp.code_pin} o modificar el código para usar {physical_pin}.",
            "El pin informado por el agente no coincide con el pin definido en el código.",
            ProblemClass.INCORRECT_CONNECTION,
        )

    return Diagnosis(
        exp.sensor, exp.signal, exp.code_pin, physical_pin,
        "Sí" if pin_match else "Parcial",
        detected_config,
        "No se requiere corrección con la evidencia disponible.",
        "La conexión y configuración observadas son compatibles con el código.",
        ProblemClass.NO_PROBLEM if pin_match else ProblemClass.INSUFFICIENT_INFO,
    )


def normalize_pin(pin: str) -> str:
    value = str(pin).strip().upper()
    value = value.replace("GPIO_NUM_", "").replace("GPIO", "").replace("PIN_", "")
    value = value.replace("D", "") if value.startswith("D") and value[1:].isdigit() else value
    return value


def normalize_address(address: str) -> str:
    value = str(address).strip().lower()
    try:
        return hex(int(value, 0))
    except ValueError:
        return value
