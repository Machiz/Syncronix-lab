from __future__ import annotations

import json
import sqlite3
import time
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any


class SensorCatalog:
    def __init__(self, db_path: str | Path, seed_path: str | Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()
        self._load_seed(Path(seed_path))

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS sensors (
                    canonical_name TEXT PRIMARY KEY,
                    aliases TEXT NOT NULL DEFAULT '[]',
                    interface TEXT NOT NULL DEFAULT '',
                    voltage_min REAL,
                    voltage_max REAL,
                    addresses TEXT NOT NULL DEFAULT '[]',
                    pins TEXT NOT NULL DEFAULT '{}',
                    summary TEXT NOT NULL DEFAULT '',
                    source_url TEXT NOT NULL DEFAULT '',
                    source_kind TEXT NOT NULL DEFAULT 'bundled',
                    updated_at INTEGER NOT NULL DEFAULT 0
                )
                """
            )

    def _load_seed(self, seed_path: Path) -> None:
        data = json.loads(seed_path.read_text(encoding="utf-8"))
        with self._connect() as conn:
            for item in data:
                conn.execute(
                    """
                    INSERT OR IGNORE INTO sensors
                    (canonical_name, aliases, interface, voltage_min, voltage_max,
                     addresses, pins, summary, source_url, source_kind, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'bundled', ?)
                    """,
                    (
                        item["canonical_name"],
                        json.dumps(item.get("aliases", []), ensure_ascii=False),
                        item.get("interface", ""),
                        item.get("voltage_min"),
                        item.get("voltage_max"),
                        json.dumps(item.get("addresses", []), ensure_ascii=False),
                        json.dumps(item.get("pins", {}), ensure_ascii=False),
                        item.get("summary", ""),
                        item.get("source_url", ""),
                        int(time.time()),
                    ),
                )

    def find(self, name: str) -> dict[str, Any] | None:
        target = name.strip().lower()
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM sensors").fetchall()
        for row in rows:
            aliases = json.loads(row["aliases"])
            candidates = [row["canonical_name"], *aliases]
            if any(target == str(candidate).lower() for candidate in candidates):
                return self._row_to_dict(row)
        return None

    def upsert_online_summary(self, name: str, summary: str, url: str) -> None:
        existing = self.find(name)
        canonical = existing["canonical_name"] if existing else name.strip()
        aliases = existing.get("aliases", []) if existing else [name.strip()]
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO sensors
                (canonical_name, aliases, summary, source_url, source_kind, updated_at)
                VALUES (?, ?, ?, ?, 'online-unverified', ?)
                ON CONFLICT(canonical_name) DO UPDATE SET
                    summary=excluded.summary,
                    source_url=excluded.source_url,
                    source_kind='online-unverified',
                    updated_at=excluded.updated_at
                """,
                (
                    canonical,
                    json.dumps(aliases, ensure_ascii=False),
                    summary,
                    url,
                    int(time.time()),
                ),
            )

    def enrich_from_wikipedia(self, sensor_name: str, timeout: float = 5.0) -> dict[str, Any] | None:
        """
        Downloads a descriptive summary only. Electrical limits and pinouts must
        come from a manufacturer datasheet or a reviewed local JSON record.
        """
        query = urllib.parse.urlencode(
            {
                "action": "query",
                "generator": "search",
                "gsrsearch": f"{sensor_name} sensor module",
                "gsrlimit": 1,
                "prop": "extracts|info",
                "exintro": 1,
                "explaintext": 1,
                "inprop": "url",
                "format": "json",
                "origin": "*",
            }
        )
        request = urllib.request.Request(
            f"https://en.wikipedia.org/w/api.php?{query}",
            headers={"User-Agent": "WireWatchMCU/0.1 educational diagnostics"},
        )
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
        pages = payload.get("query", {}).get("pages", {})
        if not pages:
            return None
        page = next(iter(pages.values()))
        summary = page.get("extract", "").strip()
        url = page.get("fullurl", "")
        if not summary:
            return None
        self.upsert_online_summary(sensor_name, summary, url)
        return self.find(sensor_name)

    def import_json(self, path: str | Path) -> int:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        items = payload if isinstance(payload, list) else [payload]
        count = 0
        with self._connect() as conn:
            for item in items:
                conn.execute(
                    """
                    INSERT INTO sensors
                    (canonical_name, aliases, interface, voltage_min, voltage_max,
                     addresses, pins, summary, source_url, source_kind, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'imported-reviewed', ?)
                    ON CONFLICT(canonical_name) DO UPDATE SET
                        aliases=excluded.aliases,
                        interface=excluded.interface,
                        voltage_min=excluded.voltage_min,
                        voltage_max=excluded.voltage_max,
                        addresses=excluded.addresses,
                        pins=excluded.pins,
                        summary=excluded.summary,
                        source_url=excluded.source_url,
                        source_kind='imported-reviewed',
                        updated_at=excluded.updated_at
                    """,
                    (
                        item["canonical_name"],
                        json.dumps(item.get("aliases", []), ensure_ascii=False),
                        item.get("interface", ""),
                        item.get("voltage_min"),
                        item.get("voltage_max"),
                        json.dumps(item.get("addresses", []), ensure_ascii=False),
                        json.dumps(item.get("pins", {}), ensure_ascii=False),
                        item.get("summary", ""),
                        item.get("source_url", ""),
                        int(time.time()),
                    ),
                )
                count += 1
        return count

    @staticmethod
    def _row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
        data = dict(row)
        data["aliases"] = json.loads(data["aliases"])
        data["addresses"] = json.loads(data["addresses"])
        data["pins"] = json.loads(data["pins"])
        return data
