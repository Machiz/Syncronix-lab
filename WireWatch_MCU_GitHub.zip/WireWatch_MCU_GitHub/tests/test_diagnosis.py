from src.wirewatch.diagnosis import diagnose_one
from src.wirewatch.models import ExpectedConnection, Telemetry, ProblemClass


def test_pin_mismatch():
    exp = ExpectedConnection(sensor="LDR", signal="AO", code_pin="34")
    obs = Telemetry(
        type="pin", sensor="LDR", signal="AO",
        physical_pin="35", mode="INPUT", detected=True
    )
    result = diagnose_one(exp, obs, None)
    assert result.classification == ProblemClass.INCORRECT_CONNECTION


def test_power_error():
    exp = ExpectedConnection(
        sensor="LDR", signal="AO", code_pin="34",
        voltage_min=3.0, voltage_max=3.6
    )
    obs = Telemetry(
        type="pin", sensor="LDR", signal="AO",
        physical_pin="34", mode="INPUT", detected=True, voltage=5.0
    )
    result = diagnose_one(exp, obs, None)
    assert result.classification == ProblemClass.INCORRECT_POWER


def test_matching_pin_is_no_problem():
    exp = ExpectedConnection(sensor="LDR", signal="AO", code_pin="34")
    obs = Telemetry(
        type="pin", sensor="LDR", signal="AO",
        physical_pin="34", mode="INPUT", detected=True
    )
    result = diagnose_one(exp, obs, None)
    assert result.classification == ProblemClass.NO_PROBLEM
