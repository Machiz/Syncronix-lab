from pathlib import Path
from tempfile import TemporaryDirectory

from src.wirewatch.code_parser import parse_source


def test_explicit_annotation():
    with TemporaryDirectory() as temp:
        path = Path(temp) / "demo.ino"
        path.write_text(
            "// @sensor LDR; signal=AO; pin=34; mode=INPUT; interface=ANALOG; voltage=3.3\n"
            "const int LDR_PIN = 34;\n",
            encoding="utf-8",
        )
        items = parse_source(path)
        assert len(items) == 1
        assert items[0].sensor == "LDR"
        assert items[0].code_pin == "34"
        assert items[0].expected_mode == "INPUT"
