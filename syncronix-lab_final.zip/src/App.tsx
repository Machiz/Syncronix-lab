import React, { useState, useEffect } from 'react';
import {
  Zap,
  Activity,
  Cpu,
  BookOpen,
  MessageSquare,
  ShieldCheck,
  Radio,
  FileCode,
  Terminal,
} from 'lucide-react';
import { BoardType, DiagnosticReport, LocalFinding } from './types';
import { MultimodalStudio } from './components/MultimodalStudio';
import { DiagnosticReportView } from './components/DiagnosticReportView';
import { SensorSheetManager } from './components/SensorSheetManager';
import { CopilotChat } from './components/CopilotChat';
import { runLocalDiagnostics } from './lib/localDiagnostics';

export function App() {
  const [activeTab, setActiveTab] = useState<'studio' | 'sheets' | 'chat'>('studio');
  const [boardType, setBoardType] = useState<BoardType>('ESP32');
  const [edgeMode, setEdgeMode] = useState<boolean>(false);
  const [firmwareCode, setFirmwareCode] = useState<string>('');
  const [serialLogs, setSerialLogs] = useState<string>('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [userContext, setUserContext] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);

  const [diagnosticReport, setDiagnosticReport] = useState<DiagnosticReport | null>(null);
  const [serverHealth, setServerHealth] = useState<{ status: string; hasApiKey: boolean } | null>(null);

  useEffect(() => {
    checkServerHealth();
  }, []);

  const checkServerHealth = async () => {
    try {
      const res = await fetch('/api/health');
      if (res.ok) {
        const data = await res.json();
        setServerHealth({ status: data.status, hasApiKey: data.hasApiKey });
      }
    } catch {
      setServerHealth({ status: 'offline', hasApiKey: false });
    }
  };

  const handleAnalyze = async () => {
    setIsAnalyzing(true);

    // 1. Run Local Deterministic Engine FIRST
    const { report: localReport, findings: localFindings } = runLocalDiagnostics(
      boardType,
      firmwareCode,
      serialLogs
    );

    // If Edge Mode is active, complete locally immediately!
    if (edgeMode) {
      setTimeout(() => {
        setDiagnosticReport(localReport);
        setIsAnalyzing(false);
      }, 400);
      return;
    }

    // 2. Cloud Multimodal Analysis (passes local findings as verified facts to Gemini)
    try {
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: imagePreview,
          firmwareCode,
          serialLogs,
          boardType,
          edgeMode,
          userContext,
          localFindings,
        }),
      });

      if (!res.ok) {
        throw new Error(`Server status ${res.status}`);
      }

      const resData = await res.json();
      if (resData.success && resData.data) {
        setDiagnosticReport(resData.data);
      } else {
        setDiagnosticReport(localReport);
      }
    } catch (err) {
      console.warn('Multimodal cloud request failed, reverting to local deterministic report:', err);
      setDiagnosticReport(localReport);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* HEADER */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-600 to-emerald-500 flex items-center justify-center shadow-lg shadow-cyan-950 text-white font-bold">
              <Zap className="w-5 h-5 fill-amber-300 text-amber-300" />
            </div>
            <div>
              <h1 className="text-sm font-bold tracking-wider text-slate-100 flex items-center gap-2">
                Syncronix Lab: <span className="text-cyan-400">VisionPulse</span>
              </h1>
              <p className="text-[10px] text-slate-400 font-mono">Multimodal Embedded Engineering Copilot</p>
            </div>
          </div>

          {/* Nav Tabs */}
          <nav className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
            <button
              type="button"
              onClick={() => setActiveTab('studio')}
              className={`px-3.5 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 transition-colors ${
                activeTab === 'studio'
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-800 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Estudio Multimodal</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('sheets')}
              className={`px-3.5 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 transition-colors ${
                activeTab === 'sheets'
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-800 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Catálogo Fichas (data/sheets)</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('chat')}
              className={`px-3.5 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 transition-colors ${
                activeTab === 'chat'
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-800 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Copiloto Asistente</span>
            </button>
          </nav>

          {/* Health Indicators */}
          <div className="hidden sm:flex items-center gap-3">
            <span
              className={`text-[10px] font-mono font-bold px-2.5 py-1 rounded-full border flex items-center gap-1.5 ${
                serverHealth?.status === 'ok'
                  ? 'bg-emerald-950/80 text-emerald-400 border-emerald-800'
                  : 'bg-slate-900 text-amber-400 border-amber-800'
              }`}
            >
              <Radio className="w-3 h-3 animate-pulse" />
              {serverHealth?.status === 'ok' ? 'Servidor Conectado' : 'Modo Standalone'}
            </span>
          </div>
        </div>
      </header>

      {/* MAIN CONTAINER */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {activeTab === 'studio' && (
          <div className="space-y-6">
            <MultimodalStudio
              boardType={boardType}
              setBoardType={setBoardType}
              edgeMode={edgeMode}
              setEdgeMode={setEdgeMode}
              firmwareCode={firmwareCode}
              setFirmwareCode={setFirmwareCode}
              serialLogs={serialLogs}
              setSerialLogs={setSerialLogs}
              imagePreview={imagePreview}
              setImagePreview={setImagePreview}
              userContext={userContext}
              setUserContext={setUserContext}
              onAnalyze={handleAnalyze}
              isAnalyzing={isAnalyzing}
            />

            {/* Diagnostic Report Results */}
            {diagnosticReport && (
              <div className="pt-4">
                <DiagnosticReportView
                  report={diagnosticReport}
                  onApplyPatch={(code) => setFirmwareCode(code)}
                />
              </div>
            )}
          </div>
        )}

        {activeTab === 'sheets' && <SensorSheetManager />}

        {activeTab === 'chat' && (
          <CopilotChat boardType={boardType} currentContext={diagnosticReport} />
        )}
      </main>

      {/* FOOTER */}
      <footer className="border-t border-slate-800 bg-slate-900/60 py-4 text-center text-xs text-slate-500 font-mono">
        <p>Syncronix Lab: VisionPulse — Verificación segura con prioridad a la evidencia dura (Código y Serie)</p>
      </footer>
    </div>
  );
}

export default App;
