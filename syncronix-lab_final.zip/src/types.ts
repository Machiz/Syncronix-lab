export type BoardType = 'ESP32' | 'Arduino Uno' | 'Raspberry Pi Pico' | 'STM32 Blue Pill';

export interface BoardRule {
  name: BoardType;
  operatingVoltage: number; // e.g. 3.3 or 5.0
  maxToleranceVoltage: number;
  gpioPins: number[];
  inputOnlyPins: number[];
  flashReservedPins: number[]; // ESP32 GPIO 6-11
  bootSensitivePins: number[]; // ESP32 GPIO 0, 2, 5, 12, 15
  adcPins: number[];
  adc2Pins: number[]; // ESP32 GPIO 0, 2, 4, 12-15, 25-27
  pwmPins: number[];
  defaultI2cSda: number;
  defaultI2cScl: number;
  defaultUartRx: number;
  defaultUartTx: number;
  hasNativeAnalogWrite: boolean;
}

export type Severity = 'critical' | 'warning' | 'info';

export interface LocalFinding {
  severity: Severity;
  code: string;
  pin?: string | number;
  title: string;
  detail: string;
}

export type PinoutStatus = 'MATCH' | 'MISMATCH' | 'MISSING' | 'UNCERTAIN';

export interface PinoutMatrixItem {
  codePin: string;
  physicalWiredPin: string;
  expectedPin: string;
  component: string;
  status: PinoutStatus;
  errorDetail: string;
}

export interface Discrepancy {
  category: 'Hardware Wiring' | 'Firmware Logic' | 'Serial Telemetry' | 'Power/Voltage';
  description: string;
  severity: Severity;
}

export interface ActionStep {
  stepNumber: number;
  title: string;
  instruction: string;
  category: 'wiring' | 'code' | 'config' | 'measurement';
}

export interface FirmwarePatch {
  hasPatch: boolean;
  correctedCode: string;
  diffSummary: string;
  changedLinesDescription: string[];
}

export interface SerialTest {
  command: string;
  expectedOutput: string;
  purpose: string;
}

export interface SensorInfo {
  id: string;
  name: string;
  model: string;
  category: 'I2C' | 'Analog ADC' | 'Digital / OneWire' | 'SPI / PWM' | 'UART / Other';
  protocol: string;
  addressOrPin: string;
  operatingVoltage: '3.3V' | '5V' | '3.3V/5V Dual';
  status: 'VERIFIED_OK' | 'PIN_MISMATCH' | 'NACK_ERROR' | 'UNTESTED' | 'BROWNOUT_RISK';
  liveReading?: string;
  wiringGuide?: string;
  codeSnippet?: string;
  description?: string;
}

export type OverallStatus =
  | 'CRITICAL_FAULT'
  | 'PIN_MISMATCH'
  | 'LOGIC_ERROR'
  | 'HARDWARE_FAULT'
  | 'VERIFIED_OK';

export interface DiagnosticReport {
  overallStatus: OverallStatus;
  confidenceScore: number;
  summary: string;
  rootCause: string;
  pinoutMatrix: PinoutMatrixItem[];
  discrepancies: Discrepancy[];
  actionSteps: ActionStep[];
  firmwarePatch: FirmwarePatch;
  suggestedSerialTests: SerialTest[];
  detectedSensors: SensorInfo[];
  schematicNotes: string;
}

export interface SheetRecord {
  canonical_name: string;
  canonicalName?: string;
  aliases?: string[];
  interface?: 'I2C' | 'SPI' | 'ANALOG' | 'DIGITAL' | 'UART' | 'ONEWIRE';
  voltage_min?: number;
  voltage_max?: number;
  operating_voltage?: string;
  summary?: string;
  source_url?: string;
  reviewed_at?: string;
  provenance?: 'bundled' | 'imported-reviewed' | 'online-unverified';
  electricallyUsable?: boolean;
  _file?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}
