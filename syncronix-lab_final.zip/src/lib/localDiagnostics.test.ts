import { runLocalDiagnostics } from './localDiagnostics';

console.log('--- TEST LOCAL DIAGNOSTICS ENGINE ---');

const sampleCode = `
#include <WiFi.h>
#define FLASH_PIN 6
#define INPUT_ONLY 34
// @sensor HC-SR04 GPIO 34

void setup() {
  Serial.begin(115200);
  pinMode(FLASH_PIN, OUTPUT);
  pinMode(INPUT_ONLY, OUTPUT);
  analogRead(25); // GPIO 25 is ADC2
}

void loop() {}
`;

const sampleLogs = 'rst:0x10 (RTCWDT_RTC_RESET),boot:0x13 (SPI_FAST_FLASH_BOOT)';

const result = runLocalDiagnostics('ESP32', sampleCode, sampleLogs);

console.log('Overall Status:', result.report.overallStatus);
console.log('Findings Count:', result.findings.length);
console.log('Findings:');
result.findings.forEach((f, i) => {
  console.log(`  ${i + 1}. [${f.severity}] ${f.code}: ${f.title}`);
});

if (result.findings.length >= 3) {
  console.log('✅ TEST PASSED: Successfully detected flash pin, input-only output, ADC2 WiFi conflict, and Brownout reset!');
} else {
  console.error('❌ TEST FAILED: Expected findings were missing.');
  process.exit(1);
}
