import { SEED_SENSORS } from '../data/sensors';
import { SheetRecord } from '../types';

const LOCAL_STORAGE_KEY = 'syncronix_sensor_catalog_v1';

export class SensorCatalog {
  private sheets: Map<string, SheetRecord> = new Map();

  constructor() {
    this.initCatalog();
  }

  private initCatalog() {
    // 1. Seed
    for (const seed of SEED_SENSORS) {
      this.sheets.set(seed.canonical_name.toLowerCase(), seed);
    }

    // 2. Local Storage
    try {
      const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (stored) {
        const parsed: SheetRecord[] = JSON.parse(stored);
        for (const item of parsed) {
          if (item.canonical_name || item.canonicalName) {
            const name = (item.canonical_name || item.canonicalName!).toLowerCase();
            this.sheets.set(name, {
              ...item,
              canonical_name: item.canonical_name || item.canonicalName!,
              electricallyUsable: item.provenance !== 'online-unverified',
            });
          }
        }
      }
    } catch {
      // localStorage may fail in iframe sandbox
    }
  }

  public async syncWithServer(): Promise<{ success: boolean; count: number }> {
    try {
      const res = await fetch('/api/sheets');
      if (!res.ok) return { success: false, count: this.sheets.size };
      const data = await res.json();
      if (data.success && Array.isArray(data.sheets)) {
        for (const serverSheet of data.sheets) {
          const name = (serverSheet.canonical_name || serverSheet.canonicalName || '').toLowerCase();
          if (name) {
            this.sheets.set(name, {
              ...serverSheet,
              canonical_name: serverSheet.canonical_name || serverSheet.canonicalName,
              provenance: serverSheet.provenance || 'imported-reviewed',
              electricallyUsable: true,
            });
          }
        }
      }
      return { success: true, count: this.sheets.size };
    } catch {
      console.warn('[Syncronix] Servidor de fichas offline, funcionando en modo local/semilla.');
      return { success: false, count: this.sheets.size };
    }
  }

  public getAll(): SheetRecord[] {
    return Array.from(this.sheets.values());
  }

  public find(query: string): SheetRecord | undefined {
    if (!query) return undefined;
    const q = query.toLowerCase().trim();

    // Exact match
    if (this.sheets.has(q)) return this.sheets.get(q);

    // Alias or partial match
    for (const sheet of this.sheets.values()) {
      if (sheet.canonical_name.toLowerCase().includes(q)) return sheet;
      if (sheet.aliases?.some((a) => a.toLowerCase().includes(q))) return sheet;
    }

    return undefined;
  }

  public async addOrUpdate(sheet: SheetRecord): Promise<boolean> {
    const name = sheet.canonical_name || sheet.canonicalName;
    if (!name) return false;

    const record: SheetRecord = {
      ...sheet,
      canonical_name: name,
      provenance: sheet.provenance || 'imported-reviewed',
      electricallyUsable: sheet.provenance !== 'online-unverified',
      reviewed_at: sheet.reviewed_at || new Date().toISOString().slice(0, 10),
    };

    this.sheets.set(name.toLowerCase(), record);

    // Save to localStorage
    try {
      const currentList = Array.from(this.sheets.values());
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(currentList));
    } catch {
      // Ignore
    }

    // Attempt POST to server
    try {
      await fetch('/api/sheets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(record),
      });
    } catch {
      // Server upload failed, local remains valid
    }

    return true;
  }
}

export const sensorCatalogInstance = new SensorCatalog();
