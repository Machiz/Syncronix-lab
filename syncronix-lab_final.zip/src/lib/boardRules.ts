import { BoardRule, BoardType } from '../types';

export const BOARD_RULES: Record<BoardType, BoardRule> = {
  ESP32: {
    name: 'ESP32',
    operatingVoltage: 3.3,
    maxToleranceVoltage: 3.6,
    gpioPins: [0, 1, 2, 3, 4, 5, 12, 13, 14, 15, 16, 17, 18, 19, 21, 22, 23, 25, 26, 27, 32, 33, 34, 35, 36, 39],
    inputOnlyPins: [34, 35, 36, 39],
    flashReservedPins: [6, 7, 8, 9, 10, 11],
    bootSensitivePins: [0, 2, 5, 12, 15],
    adcPins: [32, 33, 34, 35, 36, 39], // ADC1 (WiFi safe)
    adc2Pins: [0, 2, 4, 12, 13, 14, 15, 25, 26, 27], // ADC2 (Conflicts with active WiFi)
    pwmPins: [0, 2, 4, 5, 12, 13, 14, 15, 16, 17, 18, 19, 21, 22, 23, 25, 26, 27, 32, 33],
    defaultI2cSda: 21,
    defaultI2cScl: 22,
    defaultUartRx: 3,
    defaultUartTx: 1,
    hasNativeAnalogWrite: false, // Needs ledcAttach/ledcWrite in ESP-IDF/Arduino-ESP32
  },
  'Arduino Uno': {
    name: 'Arduino Uno',
    operatingVoltage: 5.0,
    maxToleranceVoltage: 5.5,
    gpioPins: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19],
    inputOnlyPins: [],
    flashReservedPins: [],
    bootSensitivePins: [0, 1], // RX/TX during serial upload
    adcPins: [14, 15, 16, 17, 18, 19], // A0-A5
    adc2Pins: [],
    pwmPins: [3, 5, 6, 9, 10, 11],
    defaultI2cSda: 18, // A4
    defaultI2cScl: 19, // A5
    defaultUartRx: 0,
    defaultUartTx: 1,
    hasNativeAnalogWrite: true,
  },
  'Raspberry Pi Pico': {
    name: 'Raspberry Pi Pico',
    operatingVoltage: 3.3,
    maxToleranceVoltage: 3.6,
    gpioPins: Array.from({ length: 29 }, (_, i) => i), // GPIO 0-28
    inputOnlyPins: [],
    flashReservedPins: [],
    bootSensitivePins: [],
    adcPins: [26, 27, 28], // ADC0-ADC2
    adc2Pins: [],
    pwmPins: Array.from({ length: 29 }, (_, i) => i),
    defaultI2cSda: 4,
    defaultI2cScl: 5,
    defaultUartRx: 1,
    defaultUartTx: 0,
    hasNativeAnalogWrite: true,
  },
  'STM32 Blue Pill': {
    name: 'STM32 Blue Pill',
    operatingVoltage: 3.3,
    maxToleranceVoltage: 3.6,
    gpioPins: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15], // PA/PB 0-15
    inputOnlyPins: [],
    flashReservedPins: [],
    bootSensitivePins: [2], // PB2 BOOT1
    adcPins: [0, 1, 2, 3, 4, 5, 6, 7], // PA0-PA7
    adc2Pins: [],
    pwmPins: [0, 1, 2, 3, 6, 7, 8, 9, 10],
    defaultI2cSda: 7, // PB7
    defaultI2cScl: 6, // PB6
    defaultUartRx: 10, // PA10
    defaultUartTx: 9, // PA9
    hasNativeAnalogWrite: true,
  },
};
