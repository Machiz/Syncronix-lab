export interface CodePinUsage {
  pin: number;
  mode?: 'INPUT' | 'OUTPUT' | 'INPUT_PULLUP' | 'ANALOG' | 'PWM';
  variableName?: string;
  component?: string;
}

export interface ParsedCodeMetadata {
  baudRate?: number;
  usedPins: CodePinUsage[];
  sensorAnnotations: { name: string; pin?: string | number }[];
  includesI2c: boolean;
  includesSpi: boolean;
  includesWifi: boolean;
  includesAnalogRead: boolean;
  includesAnalogWrite: boolean;
  wireBeginSda?: number;
  wireBeginScl?: number;
}

export function parseFirmwareCode(code: string): ParsedCodeMetadata {
  const meta: ParsedCodeMetadata = {
    usedPins: [],
    sensorAnnotations: [],
    includesI2c: false,
    includesSpi: false,
    includesWifi: false,
    includesAnalogRead: false,
    includesAnalogWrite: false,
  };

  if (!code || typeof code !== 'string') return meta;

  // 1. Check for @sensor annotations in comments (e.g., // @sensor SSD1306 GPIO 21)
  const sensorRegex = /@sensor\s+([A-Za-z0-9_\-\s]+?)(?:\s+(?:GPIO\s*)?(\d+))?$/gm;
  let sMatch;
  while ((sMatch = sensorRegex.exec(code)) !== null) {
    meta.sensorAnnotations.push({
      name: sMatch[1].trim(),
      pin: sMatch[2] ? parseInt(sMatch[2], 10) : undefined,
    });
  }

  // 2. Baud Rate detection
  const baudMatch = code.match(/Serial\.begin\(\s*(\d+)\s*\)/i);
  if (baudMatch) {
    meta.baudRate = parseInt(baudMatch[1], 10);
  }

  // 3. Includes / Libraries
  if (/Wire\.h|<Wire\.h>|Wire\.begin/i.test(code)) meta.includesI2c = true;
  if (/SPI\.h|<SPI\.h>|SPI\.begin/i.test(code)) meta.includesSpi = true;
  if (/WiFi\.h|<WiFi\.h>|WiFi\.begin|ESP8266WiFi/i.test(code)) meta.includesWifi = true;
  if (/analogRead\s*\(/i.test(code)) meta.includesAnalogRead = true;
  if (/analogWrite\s*\(/i.test(code)) meta.includesAnalogWrite = true;

  // 4. Custom Wire.begin(SDA, SCL)
  const wireBeginMatch = code.match(/Wire\.begin\(\s*(\d+)\s*,\s*(\d+)\s*\)/i);
  if (wireBeginMatch) {
    meta.wireBeginSda = parseInt(wireBeginMatch[1], 10);
    meta.wireBeginScl = parseInt(wireBeginMatch[2], 10);
  }

  // 5. Pin definitions: #define PIN_NAME 21, const int pin = 21, pinMode(21, OUTPUT)
  const pinMap = new Map<number, CodePinUsage>();

  const pinDefRegex = /(?:#define|const\s+int|int|#define\s+GPIO)\s+([A-Za-z0-9_]+)\s*=\s*(\d+)|#define\s+([A-Za-z0-9_]+)\s+(\d+)/g;
  let pMatch;
  const varToPin = new Map<string, number>();

  while ((pMatch = pinDefRegex.exec(code)) !== null) {
    const varName = pMatch[1] || pMatch[3];
    const pinNum = parseInt(pMatch[2] || pMatch[4], 10);
    if (!isNaN(pinNum) && pinNum >= 0 && pinNum <= 40) {
      varToPin.set(varName, pinNum);
    }
  }

  // pinMode(pin, MODE)
  const pinModeRegex = /pinMode\(\s*([A-Za-z0-9_]+)\s*,\s*(INPUT|OUTPUT|INPUT_PULLUP|INPUT_PULLDOWN)\s*\)/gi;
  let pmMatch;
  while ((pmMatch = pinModeRegex.exec(code)) !== null) {
    const target = pmMatch[1];
    const mode = pmMatch[2].toUpperCase() as any;
    const pinNum = varToPin.has(target) ? varToPin.get(target)! : parseInt(target, 10);
    if (!isNaN(pinNum) && pinNum >= 0 && pinNum <= 40) {
      pinMap.set(pinNum, { pin: pinNum, mode, variableName: target });
    }
  }

  // Capture analogRead(PIN) usage
  const arRegex = /analogRead\(\s*([A-Za-z0-9_]+)\s*\)/gi;
  let arMatch;
  while ((arMatch = arRegex.exec(code)) !== null) {
    const target = arMatch[1];
    const pinNum = varToPin.has(target) ? varToPin.get(target)! : parseInt(target, 10);
    if (!isNaN(pinNum) && pinNum >= 0 && pinNum <= 40) {
      const existing: CodePinUsage = pinMap.get(pinNum) || { pin: pinNum, variableName: target };
      existing.mode = 'ANALOG';
      pinMap.set(pinNum, existing);
    }
  }

  meta.usedPins = Array.from(pinMap.values());
  return meta;
}
