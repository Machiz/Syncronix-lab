import { BOARD_RULES } from './boardRules';
import { parseFirmwareCode } from './codeParser';
import { sensorCatalogInstance } from './sensorCatalog';
import {
  ActionStep,
  BoardType,
  DiagnosticReport,
  Discrepancy,
  LocalFinding,
  PinoutMatrixItem,
  SensorInfo,
  SerialTest,
} from '../types';

export function runLocalDiagnostics(
  boardType: BoardType,
  firmwareCode: string,
  serialLogs: string
): { report: DiagnosticReport; findings: LocalFinding[] } {
  const board = BOARD_RULES[boardType] || BOARD_RULES['ESP32'];
  const parsedCode = parseFirmwareCode(firmwareCode);
  const findings: LocalFinding[] = [];
  const discrepancies: Discrepancy[] = [];
  const matrixItems: PinoutMatrixItem[] = [];
  const actionSteps: ActionStep[] = [];
  const detectedSensors: SensorInfo[] = [];

  let stepCount = 1;

  // 1. Validate Flash Reserved Pins (ESP32 GPIO 6-11)
  for (const usage of parsedCode.usedPins) {
    if (board.flashReservedPins.includes(usage.pin)) {
      const finding: LocalFinding = {
        severity: 'critical',
        code: 'FLASH_RESERVED_PIN',
        pin: usage.pin,
        title: `GPIO ${usage.pin} Reservado para la Memoria Flash SPI`,
        detail: `El pin GPIO ${usage.pin} está conectado internamente al chip SPI Flash del ESP32. Usarlo causará fallos de arranque inmediatos (bootloop) o corrupción de código.`,
      };
      findings.push(finding);
      discrepancies.push({
        category: 'Hardware Wiring',
        description: finding.detail,
        severity: 'critical',
      });
      actionSteps.push({
        stepNumber: stepCount++,
        title: `Reasignar GPIO ${usage.pin}`,
        instruction: `Desconecta el cable del GPIO ${usage.pin} y cambia el número de pin en el código por un GPIO libre como GPIO 18, 19, 23 o 32.`,
        category: 'wiring',
      });
    }

    // 2. Input-Only Pins assigned to OUTPUT
    if (board.inputOnlyPins.includes(usage.pin) && usage.mode === 'OUTPUT') {
      const finding: LocalFinding = {
        severity: 'critical',
        code: 'INPUT_ONLY_AS_OUTPUT',
        pin: usage.pin,
        title: `GPIO ${usage.pin} es de Solo Entrada (Input-Only)`,
        detail: `Los pines GPIO 34, 35, 36 y 39 en el ESP32 no poseen transistores de salida ni resistencias de pull-up/pull-down internas. No pueden usarse como salida digital (OUTPUT).`,
      };
      findings.push(finding);
      discrepancies.push({
        category: 'Firmware Logic',
        description: finding.detail,
        severity: 'critical',
      });
      actionSteps.push({
        stepNumber: stepCount++,
        title: `Mover Salida de GPIO ${usage.pin}`,
        instruction: `Reasigna la función de salida a un pin bidireccional como GPIO 4, 16, 17 o 25.`,
        category: 'code',
      });
    }

    // 3. Boot Sensitive Pins warning
    if (board.bootSensitivePins.includes(usage.pin)) {
      findings.push({
        severity: 'warning',
        code: 'BOOT_PIN_WARNING',
        pin: usage.pin,
        title: `GPIO ${usage.pin} es un Pin Estratégico de Arranque (Strapping Pin)`,
        detail: `Si el pin GPIO ${usage.pin} se mantiene en ALTO o BAJO durante el encendido del ESP32, la placa puede entrar en modo Flash o rechazar el arranque.`,
      });
    }
  }

  // 4. ADC2 + WiFi Collision Risk
  if (parsedCode.includesWifi && parsedCode.includesAnalogRead) {
    const adc2Used = parsedCode.usedPins.filter(
      (u) => u.mode === 'ANALOG' && board.adc2Pins.includes(u.pin)
    );
    if (adc2Used.length > 0) {
      const pinsStr = adc2Used.map((u) => `GPIO ${u.pin}`).join(', ');
      const finding: LocalFinding = {
        severity: 'critical',
        code: 'ADC2_WIFI_COLLISION',
        title: `Conflicto de ADC2 con Módulo WiFi Activo`,
        detail: `Los pines de ADC2 (${pinsStr}) comparten circuito con la radio WiFi del ESP32. Cuando WiFi está activo, 'analogRead()' sobre estos pines devuelve siempre 0 o lecturas erróneas.`,
      };
      findings.push(finding);
      discrepancies.push({
        category: 'Firmware Logic',
        description: finding.detail,
        severity: 'critical',
      });
      actionSteps.push({
        stepNumber: stepCount++,
        title: `Migrar Lectura Analógica a ADC1`,
        instruction: `Mueve los sensores analógicos a pines del bloque ADC1 (GPIO 32, 33, 34, 35, 36 o 39), los cuales funcionan sin interferencia con la red WiFi.`,
        category: 'wiring',
      });
    }
  }

  // 5. ESP32 analogWrite Unsupported Notice
  if (boardType === 'ESP32' && parsedCode.includesAnalogWrite) {
    findings.push({
      severity: 'warning',
      code: 'ANALOGWRITE_ESP32',
      title: `'analogWrite()' No Soportado en Núcleo Clásico ESP32`,
      detail: `El ESP32 no dispone de DAC analógico directo mediante 'analogWrite()'. Se debe utilizar el periférico LEDC mediante 'ledcAttach()' y 'ledcWrite()'.`,
    });
  }

  // 6. Serial Log Analysis (Brownout, Watchdog, NACK, Baud Mismatch)
  if (serialLogs) {
    if (/brownout|rst:0x10|RTCWDT/i.test(serialLogs)) {
      const finding: LocalFinding = {
        severity: 'critical',
        code: 'BROWNOUT_POWER_RESET',
        title: `Reinicio por Caída de Tensión (Brownout Detector)`,
        detail: `El registro serie muestra reinicios provocados por caída de voltaje en la línea de 3.3V/5V. Ocurre típicamente al activar transceptores WiFi, motores, relevadores o la flash LED del ESP32-CAM.`,
      };
      findings.push(finding);
      discrepancies.push({
        category: 'Power/Voltage',
        description: finding.detail,
        severity: 'critical',
      });
      actionSteps.push({
        stepNumber: stepCount++,
        title: `Reforzar Fuente de Alimentación`,
        instruction: `Añade un condensador electrolítico de 100uF-470uF entre VCC y GND cerca de la placa o alimenta los periféricos de alto consumo con una fuente externa regulada.`,
        category: 'wiring',
      });
    }

    if (/NACK|Device not found|0x00|I2C error/i.test(serialLogs)) {
      discrepancies.push({
        category: 'Serial Telemetry',
        description: `Error I2C NACK detectado en consola. Dispositivo no responde o dirección incorrecta.`,
        severity: 'warning',
      });
    }
  }

  // 7. Sensor Annotations & Datasheet Matching
  for (const ann of parsedCode.sensorAnnotations) {
    const sheet = sensorCatalogInstance.find(ann.name);
    if (sheet) {
      // Check voltage compatibility
      if (sheet.voltage_min && sheet.voltage_min >= 4.5 && board.operatingVoltage <= 3.3) {
        const finding: LocalFinding = {
          severity: 'critical',
          code: 'NIVEL_5V_RISK',
          title: `Sensor a 5V '${sheet.canonical_name}' en Placa Lógica de 3.3V`,
          detail: `'${sheet.canonical_name}' trabaja nominalmente a 5V (${sheet.voltage_min}-${sheet.voltage_max}V). Conectarlo directamente a un pin del ${board.name} (3.3V máximo) puede destruir la entrada digital o inducir 5V no regulados.`,
        };
        findings.push(finding);
        discrepancies.push({
          category: 'Power/Voltage',
          description: finding.detail,
          severity: 'critical',
        });
        actionSteps.push({
          stepNumber: stepCount++,
          title: `Insertar Adaptador de Nivel Lógico`,
          instruction: `Usa un convertidor de nivel lógico bidireccional de 3.3V a 5V (p.ej. BSS138) o un divisor de tensión con resistencias (1k y 2k ohms) en la línea del sensor.`,
          category: 'wiring',
        });
      }

      detectedSensors.push({
        id: sheet.canonical_name.toLowerCase(),
        name: sheet.canonical_name,
        model: sheet.canonical_name,
        category: (sheet.interface as any) || 'Digital / OneWire',
        protocol: sheet.interface || 'Bus',
        addressOrPin: ann.pin ? `GPIO ${ann.pin}` : 'Definido en código',
        operatingVoltage: (sheet.operating_voltage as any) || (sheet.voltage_min && sheet.voltage_min >= 4.5 ? '5V' : '3.3V'),
        status: findings.some((f) => f.severity === 'critical') ? 'PIN_MISMATCH' : 'VERIFIED_OK',
        description: sheet.summary,
      });
    }
  }

  // Default fallback if no critical flaws found
  if (actionSteps.length === 0) {
    actionSteps.push({
      stepNumber: 1,
      title: 'Verificación de Tierra Común (GND)',
      instruction: 'Verifica que la línea de tierra (GND) del microcontrolador esté unida a la masa de todos los módulos sensores y fuentes de alimentación externas.',
      category: 'wiring',
    });
  }

  const hasCritical = findings.some((f) => f.severity === 'critical');
  const overallStatus = hasCritical ? 'CRITICAL_FAULT' : findings.length > 0 ? 'PIN_MISMATCH' : 'VERIFIED_OK';

  // Construct Pinout Matrix
  for (const usage of parsedCode.usedPins) {
    const isErr = findings.some((f) => f.pin === usage.pin);
    matrixItems.push({
      codePin: `GPIO ${usage.pin}`,
      physicalWiredPin: 'No verificable en foto sin medición', // As mandated by INTEGRACION.md
      expectedPin: `GPIO ${usage.pin}`,
      component: usage.variableName || 'Periférico',
      status: isErr ? 'MISMATCH' : 'MATCH',
      errorDetail: isErr ? findings.find((f) => f.pin === usage.pin)?.title || 'Conflicto de pin' : 'Configuración conforme',
    });
  }

  const report: DiagnosticReport = {
    overallStatus,
    confidenceScore: hasCritical ? 92 : 98,
    summary: hasCritical
      ? `Se detectaron ${findings.length} inconsistencias deterministas en el mapa de pines y límites del ${board.name}.`
      : `El cruce determinista entre firmware, límites del ${board.name} y telemetría no arrojó contradicciones eléctricas directas.`,
    rootCause: findings.map((f) => f.detail).join(' ') || `Configuración de hardware conforme para el objetivo ${board.name}.`,
    pinoutMatrix: matrixItems,
    discrepancies,
    actionSteps,
    firmwarePatch: {
      hasPatch: false,
      correctedCode: firmwareCode,
      diffSummary: 'Revisiones locales de pines disponibles.',
      changedLinesDescription: [],
    },
    suggestedSerialTests: [
      {
        command: 'AT',
        expectedOutput: 'OK',
        purpose: 'Verificar respuesta del bus serie',
      },
    ],
    detectedSensors,
    schematicNotes: 'Foto analizada como evidencia blanda. Realizar mediciones con multímetro en pines sospechosos.',
  };

  return { report, findings };
}
