import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Code2,
  Terminal,
  Cpu,
  Copy,
  Check,
  ShieldCheck,
  Layers,
  ArrowRight,
  Zap,
} from 'lucide-react';
import { DiagnosticReport, OverallStatus, PinoutStatus, Severity } from '../types';

interface DiagnosticReportViewProps {
  report: DiagnosticReport;
  onApplyPatch?: (code: string) => void;
}

const STATUS_CONFIG: Record<
  OverallStatus,
  { label: string; bg: string; text: string; border: string; icon: React.FC<{ className?: string }> }
> = {
  CRITICAL_FAULT: {
    label: 'FALLO CRÍTICO DETECTADO',
    bg: 'bg-rose-950/80',
    text: 'text-rose-400',
    border: 'border-rose-600/50',
    icon: XCircle,
  },
  PIN_MISMATCH: {
    label: 'DESCONEXIÓN / DISCREPANCIA DE PINES',
    bg: 'bg-amber-950/80',
    text: 'text-amber-400',
    border: 'border-amber-600/50',
    icon: AlertTriangle,
  },
  LOGIC_ERROR: {
    label: 'ERROR EN LÓGICA DE FIRMWARE',
    bg: 'bg-amber-950/80',
    text: 'text-amber-300',
    border: 'border-amber-600/50',
    icon: AlertTriangle,
  },
  HARDWARE_FAULT: {
    label: 'FALLO DE ALIMENTACIÓN O HARDWARE',
    bg: 'bg-rose-950/80',
    text: 'text-rose-300',
    border: 'border-rose-600/50',
    icon: XCircle,
  },
  VERIFIED_OK: {
    label: 'CIRCUITO Y FIRMWARE VERIFICADOS',
    bg: 'bg-emerald-950/80',
    text: 'text-emerald-400',
    border: 'border-emerald-600/50',
    icon: CheckCircle2,
  },
};

const PIN_STATUS_BADGE: Record<PinoutStatus, { label: string; bg: string; text: string }> = {
  MATCH: { label: 'COINCIDE', bg: 'bg-emerald-950', text: 'text-emerald-400' },
  MISMATCH: { label: 'CRUZADO / ERROR', bg: 'bg-rose-950', text: 'text-rose-400' },
  MISSING: { label: 'DESCONECTADO', bg: 'bg-amber-950', text: 'text-amber-400' },
  UNCERTAIN: { label: 'EVIDENCIA BLANDA', bg: 'bg-slate-900', text: 'text-slate-400' },
};

export const DiagnosticReportView: React.FC<DiagnosticReportViewProps> = ({ report, onApplyPatch }) => {
  const [copiedCode, setCopiedCode] = useState(false);
  const statusCfg = STATUS_CONFIG[report.overallStatus] || STATUS_CONFIG['CRITICAL_FAULT'];
  const StatusIcon = statusCfg.icon;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* 1. OVERALL STATUS BANNER */}
      <div className={`p-5 rounded-xl border ${statusCfg.bg} ${statusCfg.border} shadow-xl`}>
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <StatusIcon className={`w-8 h-8 ${statusCfg.text}`} />
            <div>
              <h2 className={`text-base font-bold tracking-wide ${statusCfg.text}`}>{statusCfg.label}</h2>
              <p className="text-xs text-slate-300 mt-0.5">{report.summary}</p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
            <span className="text-xs text-slate-400">Confianza:</span>
            <span className="text-xs font-mono font-bold text-cyan-300">{report.confidenceScore}%</span>
          </div>
        </div>

        {/* Root cause callout */}
        <div className="mt-4 pt-4 border-t border-slate-800/80 text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-3.5 rounded-lg">
          <span className="font-bold text-amber-400 block mb-1 uppercase tracking-wider text-[11px]">
            Causa Raíz Identificada:
          </span>
          {report.rootCause}
        </div>
      </div>

      {/* 2. PINOUT MATRIX TABLE */}
      {report.pinoutMatrix && report.pinoutMatrix.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
              <Layers className="w-4 h-4" /> Matriz de Verificación de Pines (Software vs Físico)
            </h3>
            <span className="text-[10px] text-slate-400 italic">Jerarquía de Evidencia Aplicada</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-mono text-[11px] uppercase bg-slate-950/80">
                  <th className="py-2.5 px-3">Componente</th>
                  <th className="py-2.5 px-3">Pin Firmware</th>
                  <th className="py-2.5 px-3">Cableado Foto</th>
                  <th className="py-2.5 px-3">Pin Esperado</th>
                  <th className="py-2.5 px-3 text-center">Estado</th>
                  <th className="py-2.5 px-3">Detalle Técnico</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50">
                {report.pinoutMatrix.map((item, idx) => {
                  const badge = PIN_STATUS_BADGE[item.status] || PIN_STATUS_BADGE.UNCERTAIN;
                  return (
                    <tr key={idx} className="hover:bg-slate-950/50 transition-colors">
                      <td className="py-2.5 px-3 font-semibold text-slate-200">{item.component}</td>
                      <td className="py-2.5 px-3 font-mono text-cyan-300">{item.codePin}</td>
                      <td className="py-2.5 px-3 font-mono text-amber-300">{item.physicalWiredPin}</td>
                      <td className="py-2.5 px-3 font-mono text-emerald-300">{item.expectedPin}</td>
                      <td className="py-2.5 px-3 text-center">
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-mono font-bold ${badge.bg} ${badge.text}`}>
                          {badge.label}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-400 text-[11px]">{item.errorDetail}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. DISCREPANCIES & ACTION STEPS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Discrepancies */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
          <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" /> Discrepancias Detectadas ({report.discrepancies?.length || 0})
          </h3>
          <div className="space-y-2.5">
            {report.discrepancies?.map((disc, i) => (
              <div key={i} className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-200">{disc.category}</span>
                  <span
                    className={`text-[10px] uppercase font-mono px-1.5 py-0.5 rounded ${
                      disc.severity === 'critical'
                        ? 'bg-rose-950 text-rose-400'
                        : disc.severity === 'warning'
                        ? 'bg-amber-950 text-amber-400'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {disc.severity}
                  </span>
                </div>
                <p className="text-slate-400 text-[11px]">{disc.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Action Steps */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
          <h3 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-2">
            <Zap className="w-4 h-4" /> Pasos de Corrección Seguros
          </h3>
          <div className="space-y-2.5">
            {report.actionSteps?.map((step) => (
              <div key={step.stepNumber} className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs flex gap-3">
                <span className="w-6 h-6 rounded-full bg-emerald-950 text-emerald-400 font-bold flex items-center justify-center text-xs flex-shrink-0">
                  {step.stepNumber}
                </span>
                <div className="space-y-1">
                  <h4 className="font-semibold text-slate-200">{step.title}</h4>
                  <p className="text-slate-400 text-[11px] leading-relaxed">{step.instruction}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 4. FIRMWARE PATCH */}
      {report.firmwarePatch && report.firmwarePatch.correctedCode && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
              <Code2 className="w-4 h-4" /> Parche de Firmware Corregido
            </h3>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => copyToClipboard(report.firmwarePatch.correctedCode)}
                className="px-2.5 py-1 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 rounded flex items-center gap-1 transition-colors"
              >
                {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedCode ? 'Copiado!' : 'Copiar Código'}
              </button>
              {onApplyPatch && (
                <button
                  type="button"
                  onClick={() => onApplyPatch(report.firmwarePatch.correctedCode)}
                  className="px-2.5 py-1 text-xs bg-cyan-600 hover:bg-cyan-500 text-white rounded font-medium flex items-center gap-1 transition-colors"
                >
                  Aplicar en Editor <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          <p className="text-xs text-slate-400">{report.firmwarePatch.diffSummary}</p>

          <pre className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs font-mono text-emerald-300 overflow-x-auto leading-relaxed max-h-60">
            <code>{report.firmwarePatch.correctedCode}</code>
          </pre>
        </div>
      )}

      {/* 5. SUGGESTED SERIAL TESTS & SENSORS DETECTED */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Serial tests */}
        {report.suggestedSerialTests && report.suggestedSerialTests.length > 0 && (
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
            <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-2">
              <Terminal className="w-4 h-4" /> Pruebas para Monitor Serie
            </h3>
            <div className="space-y-2">
              {report.suggestedSerialTests.map((test, i) => (
                <div key={i} className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <code className="font-bold text-amber-300 bg-slate-900 px-2 py-0.5 rounded">{test.command}</code>
                    <span className="text-[10px] text-slate-500">Esperado: {test.expectedOutput}</span>
                  </div>
                  <p className="text-[11px] text-slate-400">{test.purpose}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Detected sensors */}
        {report.detectedSensors && report.detectedSensors.length > 0 && (
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
            <h3 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
              <Cpu className="w-4 h-4" /> Componentes / Sensores Reconocidos
            </h3>
            <div className="space-y-2">
              {report.detectedSensors.map((sensor) => (
                <div key={sensor.id} className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-200">{sensor.name}</span>
                    <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950 px-1.5 py-0.5 rounded">
                      {sensor.operatingVoltage}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">{sensor.description}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
