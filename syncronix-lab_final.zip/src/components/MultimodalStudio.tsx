import React, { useState, useRef } from 'react';
import {
  Camera,
  Upload,
  Cpu,
  Code,
  Terminal,
  Zap,
  ShieldAlert,
  Play,
  RotateCcw,
  Sparkles,
  FileText,
  CheckCircle2,
} from 'lucide-react';
import { BoardType } from '../types';

interface MultimodalStudioProps {
  boardType: BoardType;
  setBoardType: (board: BoardType) => void;
  edgeMode: boolean;
  setEdgeMode: (mode: boolean) => void;
  firmwareCode: string;
  setFirmwareCode: (code: string) => void;
  serialLogs: string;
  setSerialLogs: (logs: string) => void;
  imagePreview: string | null;
  setImagePreview: (img: string | null) => void;
  userContext: string;
  setUserContext: (ctx: string) => void;
  onAnalyze: () => void;
  isAnalyzing: boolean;
}

const SAMPLE_CODES: Record<BoardType, { name: string; code: string; logs: string }> = {
  ESP32: {
    name: 'ESP32 OLED + Sensor Fail (I2C & ADC2 Collision)',
    code: `// @sensor SSD1306 GPIO 21
// @sensor HC-SR04 GPIO 34
#include <Wire.h>
#include <Adafruit_SSD1306.h>
#include <WiFi.h>

#define OLED_SDA 22  // Mismatch! In physical setup SDA is connected to GPIO 21
#define OLED_SCL 21  // Mismatch! SCL connected to GPIO 22
#define SOIL_ADC 25  // ADC2 Channel - Conflicts when WiFi is connected!
#define FLASH_PIN 6  // FLASH RESERVED PIN (SPI Flash Bootloop!)

Adafruit_SSD1306 display(128, 64, &Wire, -1);

void setup() {
  Serial.begin(115200);
  WiFi.begin("Lab_Guest_SSID", "SecretPass123");
  
  pinMode(FLASH_PIN, OUTPUT);
  digitalWrite(FLASH_PIN, HIGH);
  
  Wire.begin(OLED_SDA, OLED_SCL);
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("SSD1306 allocation failed");
  }
}

void loop() {
  int soilVal = analogRead(SOIL_ADC);
  Serial.print("Soil Moisture: ");
  Serial.println(soilVal);
  delay(1000);
}`,
    logs: `[00:01:02] rst:0x10 (RTCWDT_RTC_RESET),boot:0x13 (SPI_FAST_FLASH_BOOT)
[00:01:02] configsip: 0, SPIWP:0xee
[00:01:02] clk_drv:0x00,q_drv:0x00,d_drv:0x00,cs0_drv:0x00,hd_drv:0x00,wp_drv:0x00
[00:01:03] WiFi connected! IP: 192.168.1.105
[00:01:03] SSD1306 allocation failed (I2C NACK error on SDA 22 SCL 21)
[00:01:04] Soil Moisture: 0 (ADC2 active during WiFi burst)`,
  },
  'Arduino Uno': {
    name: 'Uno HC-SR04 5V Level Mismatch',
    code: `// @sensor HC-SR04 GPIO 2
#define TRIG_PIN 2
#define ECHO_PIN 3

void setup() {
  Serial.begin(9600);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
}

void loop() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  
  long duration = pulseIn(ECHO_PIN, HIGH);
  float distance = duration * 0.034 / 2;
  Serial.print("Distance: ");
  Serial.print(distance);
  Serial.println(" cm");
  delay(500);
}`,
    logs: `[00:00:01] Distance: 0.00 cm
[00:00:02] Distance: 0.00 cm (Echo timeout)`,
  },
  'Raspberry Pi Pico': {
    name: 'Pico I2C Sensor Bus Setup',
    code: `// @sensor BME280 GPIO 4
#include <Wire.h>

void setup() {
  Serial.begin(115200);
  Wire.setSDA(4);
  Wire.setSCL(5);
  Wire.begin();
}

void loop() {
  Wire.beginTransmission(0x76);
  if (Wire.endTransmission() == 0) {
    Serial.println("BME280 ACK Received");
  } else {
    Serial.println("BME280 NACK Error");
  }
  delay(1000);
}`,
    logs: `[00:00:01] BME280 ACK Received`,
  },
  'STM32 Blue Pill': {
    name: 'Blue Pill UART & PWM Motor Test',
    code: `// @sensor L298N GPIO 0
#define PWM_MOTOR PA0

void setup() {
  Serial.begin(115200);
  pinMode(PWM_MOTOR, OUTPUT);
}

void loop() {
  analogWrite(PWM_MOTOR, 128);
  Serial.println("Motor Duty: 50%");
  delay(1000);
}`,
    logs: `[00:00:01] Motor Duty: 50%
[00:00:02] Brownout detected! Supply voltage dropped below 3.1V`,
  },
};

export const MultimodalStudio: React.FC<MultimodalStudioProps> = ({
  boardType,
  setBoardType,
  edgeMode,
  setEdgeMode,
  firmwareCode,
  setFirmwareCode,
  serialLogs,
  setSerialLogs,
  imagePreview,
  setImagePreview,
  userContext,
  setUserContext,
  onAnalyze,
  isAnalyzing,
}) => {
  const [isCameraActive, setIsCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const startCamera = async () => {
    try {
      setIsCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
    } catch (err) {
      console.error('Camera access failed:', err);
      setIsCameraActive(false);
      alert('No se pudo acceder a la cámara. Por favor sube una imagen de circuito.');
    }
  };

  const captureCameraFrame = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 1280;
    canvas.height = videoRef.current.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      setImagePreview(dataUrl);
    }
    stopCamera();
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const loadPresetSample = () => {
    const preset = SAMPLE_CODES[boardType];
    if (preset) {
      setFirmwareCode(preset.code);
      setSerialLogs(preset.logs);
      setUserContext(`Prueba de laboratorio sobre ${boardType}: ${preset.name}`);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* LEFT COLUMN: Inputs & Circuit Media */}
      <div className="lg:col-span-6 space-y-6">
        {/* Target Board & Engine Configuration */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
            <div className="flex items-center gap-2 text-cyan-400 font-semibold text-sm">
              <Cpu className="w-5 h-5 text-cyan-400" />
              <span>OBJETIVO Y MODO DE DIAGNÓSTICO</span>
            </div>

            {/* Edge Mode Toggle Switch */}
            <div className="flex items-center gap-3 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
              <span className={`text-xs font-semibold ${edgeMode ? 'text-emerald-400' : 'text-slate-400'}`}>
                {edgeMode ? 'Modo Edge (Offline Determinista)' : 'Modo Nube (Multimodal IA + Local)'}
              </span>
              <button
                type="button"
                onClick={() => setEdgeMode(!edgeMode)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  edgeMode ? 'bg-emerald-600' : 'bg-cyan-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    edgeMode ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {(['ESP32', 'Arduino Uno', 'Raspberry Pi Pico', 'STM32 Blue Pill'] as BoardType[]).map((board) => (
              <button
                key={board}
                type="button"
                onClick={() => setBoardType(board)}
                className={`px-3 py-2 text-xs font-medium rounded-lg border transition-all text-center ${
                  boardType === board
                    ? 'bg-cyan-950/80 border-cyan-500 text-cyan-200 shadow-md shadow-cyan-950'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                {board}
              </button>
            ))}
          </div>
        </div>

        {/* Physical Circuit & Diagram Capture */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-cyan-400 font-semibold text-sm">
              <Camera className="w-5 h-5" />
              <span>EVIDENCIA FÍSICA / FOTO O ESQUEMA</span>
            </div>

            {imagePreview && (
              <button
                type="button"
                onClick={() => setImagePreview(null)}
                className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Quitar imagen
              </button>
            )}
          </div>

          {/* Camera Viewport or Upload Area */}
          <div className="relative min-h-[220px] rounded-lg border-2 border-dashed border-slate-800 bg-slate-950 flex flex-col items-center justify-center overflow-hidden group">
            {isCameraActive ? (
              <div className="relative w-full h-[260px] bg-black">
                <video ref={videoRef} className="w-full h-full object-cover" autoPlay playsInline />
                <div className="absolute bottom-3 left-0 right-0 flex justify-center gap-3">
                  <button
                    type="button"
                    onClick={captureCameraFrame}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-medium text-xs flex items-center gap-2 shadow-lg"
                  >
                    <Camera className="w-4 h-4" /> Capturar Foto
                  </button>
                  <button
                    type="button"
                    onClick={stopCamera}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs"
                  >
                    Cancelar
                  </button>
                </div>
              </div>
            ) : imagePreview ? (
              <div className="relative w-full h-[240px] p-2 flex items-center justify-center bg-slate-950">
                <img
                  src={imagePreview}
                  alt="Circuit preview"
                  className="max-h-full max-w-full object-contain rounded border border-slate-800"
                />
              </div>
            ) : (
              <div className="p-6 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-cyan-400">
                  <Upload className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs font-medium text-slate-300">Fotografía de Protoboard o Esquema SVG/PNG</p>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Evidencia blanda para verificación de componentes y faltantes
                  </p>
                </div>
                <div className="flex flex-wrap justify-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={startCamera}
                    className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-medium rounded-lg flex items-center gap-1.5 border border-slate-700"
                  >
                    <Camera className="w-4 h-4" /> Activar Cámara Web
                  </button>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3.5 py-1.5 bg-cyan-950 hover:bg-cyan-900 text-cyan-200 text-xs font-medium rounded-lg flex items-center gap-1.5 border border-cyan-800"
                  >
                    <Upload className="w-4 h-4" /> Seleccionar Archivo
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*,.svg"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </div>
              </div>
            )}
          </div>

          {/* User Notes */}
          <div>
            <label className="block text-[11px] font-medium text-slate-400 mb-1">
              Observaciones o síntomas detectados por el ingeniero:
            </label>
            <input
              type="text"
              value={userContext}
              onChange={(e) => setUserContext(e.target.value)}
              placeholder="Ej: La pantalla OLED no enciende y el ESP32 se calienta al conectar el sensor..."
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>
      </div>

      {/* RIGHT COLUMN: Firmware & Serial Terminal */}
      <div className="lg:col-span-6 space-y-6">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-cyan-400 font-semibold text-sm">
              <Code className="w-5 h-5" />
              <span>CÓDIGO FIRMWARE (C++ / Arduino / ESP-IDF)</span>
            </div>

            <button
              type="button"
              onClick={loadPresetSample}
              className="text-xs bg-cyan-950 text-cyan-300 hover:bg-cyan-900 px-2.5 py-1 rounded border border-cyan-800 flex items-center gap-1 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Cargar Ejemplo {boardType}
            </button>
          </div>

          <div className="relative">
            <textarea
              value={firmwareCode}
              onChange={(e) => setFirmwareCode(e.target.value)}
              placeholder="// Pega aquí tu código firmware con #define de pines e incluye etiquetas // @sensor..."
              rows={10}
              className="w-full font-mono text-xs bg-slate-950 border border-slate-800 rounded-lg p-3 text-cyan-100 placeholder-slate-600 focus:outline-none focus:border-cyan-500 leading-relaxed"
            />
          </div>
        </div>

        {/* Serial Telemetry Logs */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-cyan-400 font-semibold text-sm">
              <Terminal className="w-5 h-5 text-amber-400" />
              <span>MONITOR DE REGISTROS SERIE / TELEMETRÍA</span>
            </div>
            <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-950 text-slate-400 border border-slate-800">
              Evidencia Dura
            </span>
          </div>

          <textarea
            value={serialLogs}
            onChange={(e) => setSerialLogs(e.target.value)}
            placeholder="[00:01:02] rst:0x10 (RTCWDT_RTC_RESET)... Pega aquí la salida del monitor serie."
            rows={5}
            className="w-full font-mono text-xs bg-slate-950 border border-slate-800 rounded-lg p-3 text-amber-200 placeholder-slate-600 focus:outline-none focus:border-amber-500/50 leading-relaxed"
          />
        </div>

        {/* ACTION BUTTON: RUN VISIONPULSE ANALYSIS */}
        <button
          type="button"
          onClick={onAnalyze}
          disabled={isAnalyzing}
          className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-cyan-600 via-teal-600 to-emerald-600 hover:from-cyan-500 hover:to-emerald-500 text-white font-bold text-sm tracking-wide shadow-xl shadow-cyan-950 border border-cyan-400/30 flex items-center justify-center gap-3 transition-all transform active:scale-[0.99] disabled:opacity-50"
        >
          {isAnalyzing ? (
            <>
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              <span>PROCESANDO DIAGNÓSTICO EN TIEMPO REAL...</span>
            </>
          ) : (
            <>
              <Zap className="w-5 h-5 text-amber-300 fill-amber-300" />
              <span>EJECUTAR DIAGNÓSTICO MULTIMODAL VISIONPULSE</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
