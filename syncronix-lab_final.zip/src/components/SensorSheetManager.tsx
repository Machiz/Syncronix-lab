import React, { useState, useEffect } from 'react';
import {
  Search,
  BookOpen,
  Plus,
  Upload,
  Check,
  AlertCircle,
  ExternalLink,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { SheetRecord } from '../types';
import { sensorCatalogInstance } from '../lib/sensorCatalog';

export const SensorSheetManager: React.FC = () => {
  const [sheets, setSheets] = useState<SheetRecord[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedInterface, setSelectedInterface] = useState<string>('ALL');
  const [jsonInput, setJsonInput] = useState('');
  const [showImportModal, setShowImportModal] = useState(false);
  const [importStatus, setImportStatus] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);

  useEffect(() => {
    loadSheets();
  }, []);

  const loadSheets = async () => {
    await sensorCatalogInstance.syncWithServer();
    setSheets(sensorCatalogInstance.getAll());
  };

  const filteredSheets = sheets.filter((s) => {
    const matchesQuery =
      s.canonical_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.aliases?.some((a) => a.toLowerCase().includes(searchQuery.toLowerCase())) ||
      s.summary?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesInterface =
      selectedInterface === 'ALL' || s.interface === selectedInterface;

    return matchesQuery && matchesInterface;
  });

  const handleImportJson = async () => {
    setImportStatus(null);
    try {
      const parsed = JSON.parse(jsonInput);
      const items = Array.isArray(parsed) ? parsed : [parsed];
      let importedCount = 0;

      for (const item of items) {
        if (!item.canonical_name && !item.canonicalName) {
          throw new Error('Falta el campo obligatorio "canonical_name" en el objeto.');
        }
        await sensorCatalogInstance.addOrUpdate(item);
        importedCount++;
      }

      setImportStatus({
        msg: `¡Éxito! Se importaron y guardaron ${importedCount} ficha(s) en el repositorio offline.`,
        type: 'success',
      });
      setJsonInput('');
      loadSheets();
      setTimeout(() => setShowImportModal(false), 2000);
    } catch (err: any) {
      setImportStatus({
        msg: `Error al procesar JSON: ${err.message}`,
        type: 'error',
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-sm font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
              <BookOpen className="w-5 h-5" /> Repositorio Local de Fichas de Componentes (data/sheets)
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Catálogo de hojas de datos con respaldo offline en disco y localStorage. No requiere internet para diagnósticos eléctricos.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setShowImportModal(!showImportModal)}
            className="px-3.5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg font-medium text-xs flex items-center gap-2 transition-colors shadow-lg"
          >
            <Plus className="w-4 h-4" /> Importar Ficha JSON Revisada
          </button>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar por nombre (ej: HC-SR04, SSD1306, BME280)..."
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex gap-1 overflow-x-auto pb-1">
            {['ALL', 'I2C', 'SPI', 'ANALOG', 'DIGITAL', 'ONEWIRE', 'UART'].map((iface) => (
              <button
                key={iface}
                type="button"
                onClick={() => setSelectedInterface(iface)}
                className={`px-3 py-1.5 text-xs rounded-lg border font-mono transition-colors ${
                  selectedInterface === iface
                    ? 'bg-cyan-950 text-cyan-300 border-cyan-700 font-bold'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700'
                }`}
              >
                {iface}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Import Modal / Accordion */}
      {showImportModal && (
        <div className="bg-slate-900 border border-cyan-500/50 rounded-xl p-5 shadow-2xl space-y-3">
          <h3 className="text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-2">
            <Upload className="w-4 h-4" /> Estructura de Ficha JSON Revisada
          </h3>
          <p className="text-xs text-slate-400">
            Puedes pegar una ficha o arreglo de fichas. El servidor escribirá el archivo en <code className="text-amber-300">data/sheets/*.json</code>.
          </p>

          <textarea
            value={jsonInput}
            onChange={(e) => setJsonInput(e.target.value)}
            placeholder={`[\n  {\n    "canonical_name": "SEN0193",\n    "aliases": ["sensor humedad suelo capacitivo"],\n    "interface": "ANALOG",\n    "voltage_min": 3.3,\n    "voltage_max": 5.5,\n    "summary": "Sensor capacitivo de humedad de suelo v1.2."\n  }\n]`}
            rows={6}
            className="w-full font-mono text-xs bg-slate-950 border border-slate-800 rounded-lg p-3 text-cyan-200 placeholder-slate-600 focus:outline-none focus:border-cyan-500"
          />

          {importStatus && (
            <div
              className={`p-3 rounded-lg text-xs flex items-center gap-2 ${
                importStatus.type === 'success'
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                  : 'bg-rose-950 text-rose-300 border border-rose-800'
              }`}
            >
              {importStatus.type === 'success' ? <Check className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
              <span>{importStatus.msg}</span>
            </div>
          )}

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowImportModal(false)}
              className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-lg"
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={handleImportJson}
              className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs rounded-lg"
            >
              Guardar en Repositorio
            </button>
          </div>
        </div>
      )}

      {/* Grid of Sheets */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredSheets.map((sheet) => (
          <div
            key={sheet.canonical_name}
            className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-4 shadow-lg flex flex-col justify-between space-y-3 transition-colors"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-cyan-300">{sheet.canonical_name}</span>
                <span className="text-[10px] font-mono font-bold bg-slate-950 text-emerald-400 border border-emerald-900 px-2 py-0.5 rounded">
                  {sheet.voltage_min ? `${sheet.voltage_min}-${sheet.voltage_max}V` : sheet.operating_voltage || '3.3V-5V'}
                </span>
              </div>

              <div className="flex flex-wrap gap-1">
                <span className="text-[10px] font-mono bg-cyan-950 text-cyan-300 px-1.5 py-0.5 rounded">
                  Bus: {sheet.interface || 'GENERIC'}
                </span>
                <span className="text-[10px] font-mono bg-slate-950 text-slate-400 px-1.5 py-0.5 rounded border border-slate-800">
                  {sheet.provenance || 'bundled'}
                </span>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed">{sheet.summary}</p>
            </div>

            {sheet.source_url && (
              <a
                href={sheet.source_url}
                target="_blank"
                rel="noreferrer"
                className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 pt-2 border-t border-slate-800/80"
              >
                Hoja de Datos Oficial <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
